CREATE INDEX "#__users_email_lower" ON "#__users" (lower("email"));

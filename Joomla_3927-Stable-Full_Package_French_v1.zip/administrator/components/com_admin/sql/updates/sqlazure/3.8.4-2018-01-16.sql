ALTER TABLE [#__user_keys] DROP CONSTRAINT [#__user_keys$series_2];
ALTER TABLE [#__user_keys] DROP CONSTRAINT [#__user_keys$series_3];
